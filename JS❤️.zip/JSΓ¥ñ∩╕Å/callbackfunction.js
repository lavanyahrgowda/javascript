// call back function
// setTimeout(function() {
//   console.log("timesr");
// }, 5000);
// function x(y) {
//   console.log("timesr x");
//   y();
// }

// x(function y() {
//   console.log("timesr y");
// });
// function attachedEventListner() {
//   let count = 0;
//   document.getElementById("clickme").addEventListener("click", function xyz() {
//     console.log("clicked", ++count);
//   });
// }
// attachedEventListner();
