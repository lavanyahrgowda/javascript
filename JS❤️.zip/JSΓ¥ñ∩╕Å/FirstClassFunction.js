// function statement aka function decalartion

function a() {
  console.log("called a");
}

// function expression
var b = function(param1) {
  return function() {};
};
//annoymouse functio
// function () {

// }
a();
console.log(b());
// named fuction expression
