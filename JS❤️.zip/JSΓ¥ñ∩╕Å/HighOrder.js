// function x() {
//   console.log("Hi");
// }
// function y(x) {
//   x();
// }
// y();

const radius = [3, 1, 2, 4];
const area = function(radius) {
  return Math.PI * radius * radius;
};

Array.prototype.calculate = function(arr, logic) {
  const output = [];
  for (let i = 0; i < arr.length; i++) {
    output.push(logic(arr[i]));
  }
  return output;
};
console.log(radius.map(area));
console.log(calculate(radius, area));
