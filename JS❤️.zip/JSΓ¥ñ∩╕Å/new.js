// function test() {
//   var a = "hello";
//   let b = "bye";
//   if (true) {
//     let a = "Hii";
//     var b = "byed";
//     console.log(a);
//     console.log(b);
//   }
// }
// test();

//2

// console.log(count);
// let count = 1;

// function abc() {
//   console.log(a, b, c);
//   const b = 10;
//   let c = 20;
//   var a = 1000;
// }
// abc();

//3 first class function
// function squre(num) {
//   return num * num;
// }
// function display(fn) {
//   console.log("Squre is " + fn(6));
// }

// display(squre);

//4 IIFE

// (function(x) {
//   return (function(y) {
//     console.log(x);
//   })(2);
// })(1);

//5
for (let i = 0; i < 8; i++) {
  setTimeout(function() {
    console.log(i);
  }, i * 1000);
}
