var x = 7;
function getName() {
  console.log("hello");
}
// getName();
console.log(x);
console.log(getName);
