var a = 10;
function b() {
  var x = 10;
}
console.log(window.a);
console.log(a);
console.log(x);
