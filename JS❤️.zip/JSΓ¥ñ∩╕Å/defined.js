console.log(a);
var a = 10;
console.log(a);
if (a === undefined) {
  console.log("a is undefined e");
} else {
  console.log("a is not undefined ");
}
