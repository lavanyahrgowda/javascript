const c = 1000;
{
  var a = 10;
  let b = 10;
  const c = 20;
  console.log(a);
  console.log(b);
  console.log(c);
}
console.log(c);
