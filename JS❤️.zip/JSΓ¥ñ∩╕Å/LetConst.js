// console.log(b);
console.log(a);
let a = 10;
// console.log(a);
var b = 100;
